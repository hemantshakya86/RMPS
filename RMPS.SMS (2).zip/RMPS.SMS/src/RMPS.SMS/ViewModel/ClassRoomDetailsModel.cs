﻿using System;
using TestFramework;

namespace RMPS.SMS.ViewModel
{
    [KnockoutModel]
    public class ClassRoomDetailsModel
    {
        public Guid ID { get; set; }
        public string Name { get; set; }
    }
}
