﻿using System;
using TestFramework;

namespace RMPS.SMS.ViewModel
{
    [KnockoutModel]
    public class ClassRoomModel
    {
        public int ID { get; set; }
        public string Name { get; set; }
        //public string Section { get; set; }
    }
}
