﻿(function () {
    $(document).ready(function () {
        if ($(".selectpicker").length > 0) {
            $('.selectpicker').selectpicker();
        }
        //var events, someday, today, tomorrow;
        //if ($('#events-calendar').length > 0) {
        //    today = moment().utc().format("YYYY-MM-DD HH:MM:SS");
        //    tomorrow = moment().utc().add('days', 1).format("YYYY-MM-DD HH:MM:SS");
        //    someday = moment().utc().add('days', 3).format("YYYY-MM-DD HH:MM:SS");
        //    events = [
        //      {
        //          "date": today,
        //          "type": "meeting",
        //          "title": "Mattis Cras",
        //          "description": "Ipsum Consectetur Etiam Nibh",
        //          "url": "http://www.event1.com/"
        //      }, {
        //          "date": tomorrow,
        //          "type": "meeting",
        //          "title": "Pellentesque Parturient Dolor",
        //          "description": "Donec ullamcorper nulla non metus auctor fringilla.",
        //          "url": "http://www.event1.com/"
        //      }, {
        //          "date": someday,
        //          "type": "meeting",
        //          "title": "Ligula",
        //          "description": "Nulla vitae elit libero, a pharetra augue.",
        //          "url": "http://www.event1.com/"
        //      }
        //    ];
        //    $("#events-calendar").eventCalendar({
        //        jsonData: events,
        //        jsonDateFormat: 'human'
        //    });
        //}

    });

}).call(this);




