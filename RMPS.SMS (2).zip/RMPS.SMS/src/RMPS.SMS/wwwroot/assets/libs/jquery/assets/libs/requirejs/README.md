# requirejs-bower

Bower packaging for [RequireJS](http://requirejs.org).

